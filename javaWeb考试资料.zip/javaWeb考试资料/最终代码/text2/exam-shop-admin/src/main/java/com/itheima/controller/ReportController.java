package com.itheima.controller;

import com.itheima.pojo.Option;
import com.itheima.pojo.Product;
import com.itheima.pojo.Result;
import com.itheima.service.ReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * @Author: 滴滴滴
 * @CreateTime: 2024-12-13
 * @Description: 图片展示
 * @Version: 1.0
 */
@Slf4j
@RestController
@RequestMapping("/report")
public class ReportController {

    @Autowired
    private ReportService reportService;

    /*
     * 统计上架与下架商品的数量
     * */
    @GetMapping("/productUpOrDown")
    public Result upOrDown(){
        log.info("统计上架与下架商品的数量");
        List<Map> findUpOrDownNumberList = reportService.findUpOrDown();
        return Result.success(findUpOrDownNumberList);
    }

    /*
    * 各个状态的商品数量统计
    * */
    @GetMapping("/productStatus")
    public Result status(){
        log.info("各个状态的商品数量统计");
        List<Map> numberList = reportService.findStatus();
        return Result.success(numberList);
    }

}
