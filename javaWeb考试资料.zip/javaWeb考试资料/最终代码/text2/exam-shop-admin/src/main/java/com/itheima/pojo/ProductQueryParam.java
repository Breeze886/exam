package com.itheima.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductQueryParam {

    private Integer page; //页码
    private Integer pageSize; //每页展示记录数
    private String name; //商品姓名
    private Integer brandId; //品牌ID
    private Integer publishStatus; //上下架状态 , 0: 下架 , 1: 上架
    private Integer verifyStatus;//审核状态, 0: 未审核, 1: 审核通过, 2: 审核未通过

    private String brandName; //部门名称
}
