package com.itheima.service.impl;

import com.itheima.mapper.ReportMapper;
import com.itheima.pojo.Option;
import com.itheima.pojo.Product;
import com.itheima.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @Author: 滴滴滴
 * @CreateTime: 2024-12-13
 * @Description:
 * @Version: 1.0
 */
@Service
public class ReportServiceImpl implements ReportService {
    @Autowired
    private ReportMapper reportMapper;

    @Override
    public List<Map> findUpOrDown() {
        List<Map> list = reportMapper.countRoport();
        return list;
    }

    @Override
    public List<Map> findStatus() {
        return reportMapper.countShengHe();
    }
}
