package com.itheima.service;

import com.itheima.pojo.Option;

import java.util.List;
import java.util.Map;


public interface ReportService {
    //上下架统计
    List<Map> findUpOrDown();
    //审核结果统计
    List<Map> findStatus();

}
