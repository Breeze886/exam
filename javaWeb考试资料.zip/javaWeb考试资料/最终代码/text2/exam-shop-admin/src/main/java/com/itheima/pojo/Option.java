package com.itheima.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author: 滴滴滴
 * @CreateTime: 2024-12-13
 * @Description:
 * @Version: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Option {
    private List name;//上下架的描述
    private List value;//对应的数量
}
