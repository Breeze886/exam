package com.itheima.mapper;

import com.itheima.pojo.Product;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface ReportMapper {


    List<Map> countRoport();


    List<Map> countShengHe();
}
