import{r as i}from"./request-ce66dfbf.js";const t=o=>i.post("/login",o),e=()=>i.get("/index");export{e as i,t as l};
